public class HelloGoodbye {
    public static void main(String[] args) {
        String first = args[0];
        String second = args[1];

        // hello
        System.out.println("hello " + first + " and " + second);
        // Goodbye
        System.out.println("goodbye " + second + " and " + first);
    }
}
